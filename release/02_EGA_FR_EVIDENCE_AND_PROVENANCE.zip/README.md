# EGA French provenance and decisions — r7

Flattened, privacy-projected evidence for the complete independent diplomatic French cumulative edition, EGA I (including Chapter 0) through IV-4.

This successor removes one stale non-typeset source-driver comment that falsely described EGA III-1 as having a live cursor. The diplomatic body and both reader PDFs are unchanged. The exact operation and inverse are recorded in `guardian-controls/EGA_COMPLETE_METADATA_D12.json`.
