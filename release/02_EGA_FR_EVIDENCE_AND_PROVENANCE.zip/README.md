# EGA release evidence

This flattened package binds the terminal cumulative release. It contains no nested ZIP files and no private local paths. The French and English editions are independent. French is diplomatic; English records source-grounded corrected readings.

Earlier evidence remains citable through the predecessor version DOIs; predecessor archive bytes are not nested here.
