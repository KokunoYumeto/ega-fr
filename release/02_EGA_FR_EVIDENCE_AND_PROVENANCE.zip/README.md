# EGA French r9 provenance and decisions

This compact archive binds the complete 189-member UTF-8/LF diplomatic French
source tree, the deterministic r9 cumulative-reader receipt, and the exact PDF
inventory.  The cumulative reader is rebuilt from the current source tree; the
EGA IV-4 standalone reader is carried forward byte-for-byte.

Printed French language, notation, structure, and authorial readings remain
diplomatic.  Verified corrections are tracked separately by the Canon controls.
This is an independent French edition, never a bilingual, paired, parallel,
side-by-side, or interleaved reader.
