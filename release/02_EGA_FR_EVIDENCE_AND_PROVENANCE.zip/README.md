# EGA French provenance and decisions — r8

Flattened, privacy-projected evidence for the complete independent diplomatic French cumulative edition, EGA I (including Chapter 0) through IV-4.

This source-only successor normalizes the final three inherited CRLF-bearing source paths to UTF-8/LF. TeX tokens, diplomatic body text, and both reader PDFs are unchanged. Exact pre/post identities and inverses are in `guardian-controls/EGA_SOURCE_LF_D13.json` and `release-controls/SOURCE_LF_INVERSE.json`.
