# EGA French editable sources

Stable language concept DOI: https://doi.org/10.5281/zenodo.21921588
Exact release DOI: https://doi.org/10.5281/zenodo.22058760
Global EGA directory DOI: https://doi.org/10.5281/zenodo.20414353

## Declared scope

EGA I (including Chapter 0), complete EGA II, complete EGA III-1 through its final printed page 511, and the sealed complete EGA III-2 handoff (printed pages 137-223; page 216 blank). The wider French EGA I-IV transcription remains a cumulative work in progress.

Direct diplomatic transcription from the NUMDAM French authority.

The `source/` tree is the exact active source set enumerated by
`SOURCE_MANIFEST.json`. This archive is independent of the other language
edition and contains no bilingual, parallel, side-by-side, or interleaved reader.

Source files: 21
Source bytes: 2672507
Ordinal source-tree SHA-256: `F2C255EABFD495A3AA38479B1760151125FDE2FFBD94ABEF351ACD810E6F02DB`

Build and QA histories, deterministic inverses, rejected candidates, and
unresolved items are in the separately deposited evidence/provenance archive.
