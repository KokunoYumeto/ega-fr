# EGA French editable sources

Stable language concept DOI: https://doi.org/10.5281/zenodo.21921588
Exact release DOI: https://doi.org/10.5281/zenodo.22072593
Global EGA directory DOI: https://doi.org/10.5281/zenodo.20414353

## Declared scope

The current cumulative diplomatic source set contains EGA I (including Chapter 0), EGA II, completed EGA III-1, and the sealed completed EGA III-2 handoff. EGA IV fascicles remain separately owned until their terminal handoffs are admitted.

French is transcribed directly and diplomatically from NUMDAM. Printed errors are preserved in the source and catalogued in the evidence archive.

The `source/` tree is exactly enumerated by `SOURCE_MANIFEST.json`.
French and English remain independent editions; this archive contains no
bilingual, parallel, paired, side-by-side, or interleaved reader.

Source files: 21
Source bytes: 2672507
Ordinal source-tree SHA-256: `F2C255EABFD495A3AA38479B1760151125FDE2FFBD94ABEF351ACD810E6F02DB`
